﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //6.Simulador de Carrito de Compras
            //● Consigna: Disponer tres CheckBox con productos y precios fijos. Un Button
            //&quot; Calcular Total&quot; debe evaluar los controles seleccionados(Checked == true), sumar
            //sus costos y mostrar el monto final en un Label.
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int montoTotal = 0;

            if (checkBox1.Checked == true) 
            {
                montoTotal += 100;
            }
            if (checkBox2.Checked == true)
            {
                montoTotal += 500;
            }
            if (checkBox3.Checked == true)
            {
                montoTotal += 70;
            }

            label1.Text= montoTotal.ToString();
        }
    }
}
