﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1.UseSystemPasswordChar = true;
            //8.Validador de Credenciales y Formato
            //● Consigna: Solicitar usuario y contraseña mediante TextBox(usando
            //UseSystemPasswordChar = true). Un CheckBox &quot; Acepto términos&quot; debe habilitar
            //(Enabled = true) el Button &quot; Ingresar & quot;. Si la clave coincide con & quot; admin123 & quot;, mostrar
            //éxito en una Label; de lo contrario, mostrar advertencia.
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            button1.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "admin123") 
            {
                label2.Text = "EXITO!!";
            }
            else 
            {
                MessageBox.Show("ERROR!!");
            }
        }

    }
}
