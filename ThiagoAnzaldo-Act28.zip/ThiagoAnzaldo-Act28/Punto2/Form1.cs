﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //2.Conversor de Temperatura
            //● Consigna: Disponer un TextBox para el ingreso numérico y dos RadioButton:
            //&quot; Celsius a Fahrenheit & quot; y & quot; Fahrenheit a Celsius & quot;. Al presionar un Button, realizar la
            //fórmula correspondiente y mostrar el resultado en un Label.
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double grados=0;
            if (radioButton1.Checked) 
            {
                grados = double.Parse(textBox1.Text);

                label1.Text=((grados*1.8)+32).ToString();
            }
            if (radioButton2.Checked)
            {
                grados = double.Parse(textBox1.Text);

                label1.Text = ((grados - 32) * 0.5555555555555556).ToString();
            }
        }
    }
}
