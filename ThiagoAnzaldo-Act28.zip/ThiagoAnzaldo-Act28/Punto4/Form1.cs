﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto4
{
    public partial class Form1 : Form
    {
        //4. Temporizador de Clics(Investigación: Timer)
        //● Investigación: Explicar el componente Timer(propiedades Interval, Enabled y
        //evento Tick) con un breve ejemplo explicativo.
        //● Consigna: Crear un mini - juego donde un Button cuente cuántos clics realiza el
        //usuario en 10 segundos.Al finalizar el tiempo mediante el Timer, deshabilitar el
        //botón(Enabled = false) y mostrar el puntaje acumulado en un MessageBox.Show.
        public Form1()
        {
            InitializeComponent();
            button2.Enabled = false;
        }
        int tiempo = 10;
        int clicks=0;

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Interval = 1000;

            timer1.Start();
            button1.Enabled = false;
            button2.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            tiempo--;
            if (tiempo == 0) 
            {
                button2.Enabled=false;
                MessageBox.Show(clicks.ToString());
                button1.Enabled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clicks++;
        }
    }
}
