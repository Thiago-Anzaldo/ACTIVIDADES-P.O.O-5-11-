﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Resources.ResXFileRef;

namespace Punto1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //1.Calculadora de Promedio de Notas
            //● Consigna: Crear un formulario con tres TextBox para ingresar notas y un Button
            //&quot; Calcular & quot;. Convertir los valores con int.Parse() o double.Parse() y mostrar en una
            //Label el promedio.Si la nota es mayor o igual a 6, cambiar el color del texto de la
            //etiqueta a verde; de lo contrario, a rojo.
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sumaTotal = 0;

            sumaTotal = (int.Parse(textBox1.Text) + int.Parse(textBox2.Text) + int.Parse(textBox3.Text))/3;

            if (sumaTotal > 6) 
            {
                label1.Text = sumaTotal.ToString();
                label1.ForeColor = Color.Green;
            }
            if (sumaTotal < 6)
            {
                label1.Text = sumaTotal.ToString();
                label1.ForeColor= Color.Red;
            }
        }
    }
}
