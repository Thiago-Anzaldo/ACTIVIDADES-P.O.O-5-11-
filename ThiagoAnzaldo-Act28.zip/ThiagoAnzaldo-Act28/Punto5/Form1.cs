﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.WebRequestMethods;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace Punto5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //5.Visor Dinámico de Imágenes(Investigación: PictureBox)
            //● Investigación: Investigar la clase PictureBox y sus propiedades ImageLocation y
            //SizeMode.
            //● Consigna: Cargar en un ComboBox tres opciones. Al cambiar la selección mediante
            //el evento SelectedIndexChanged, mostrar la imagen correspondiente dentro del
            //PictureBox.
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text=="tupper")
            {
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSPrVdZKdeMX6fYcyQQGyMgittm8_r7lyNiDAHfyyplQ&s=10";
            }
            if (comboBox1.Text == "resident evil")
            {
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSK7kiXA3rqAv1hSXCLg8f3V7iLYRRKX6ou0Sv66PoZ7w&s=10";
            }
            if (comboBox1.Text == "lomas de zamora")
            {
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSmOulCmSX6K50QbVgT_7L9VtSl_MpV7JX1OEDbZnraUQ&s=10";
            }
        }
    }
}
